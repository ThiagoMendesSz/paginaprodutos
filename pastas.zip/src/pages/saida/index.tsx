import React, { useState } from "react";
import { Text, View } from "react-native";
import { Picker } from "@react-native-picker/picker";
import { Foundation, MaterialCommunityIcons } from "@expo/vector-icons";
import { Ionicons } from "@expo/vector-icons";
import { style } from "./styles";
import { themas } from "../../global/themes";
import { Input } from "../../components/input";
import { Button } from "../../components/Button";
export default function Saida(){

    const [motivo, setMotivo] = useState('Venda');

    return(
        <View style={style.container}>

            <View style={style.boxTop}>
                <Foundation name="social-dropbox" size={24} color="black" />
                <Text style={style.text}>Saída de Produto</Text>
            </View>

            <View style={style.boxMid}>

                <Input
                    title="NOME DO PRODUTO"
                    
                />

                <Input
                    title="QUANTIDADE"
                    
                    keyboardType="numeric"
                />

                <Text style={style.titleInput}>MOTIVO DA RETIRADA</Text>
                <View style={style.boxPicker}>
                    <Picker
                        selectedValue={motivo}
                        onValueChange={(valor) => setMotivo(valor)}
                        style={style.picker}
                    >
                        <Picker.Item label="Venda" value="Venda" />
                        <Picker.Item label="Avarias" value="Avarias" />
                        <Picker.Item label="Uso interno" value="Uso interno" />
                    </Picker>
                </View>

            </View>

            <View style={style.boxBottom}>
                <Button text="SAÍDA" />
            </View>

        </View>
    )
}