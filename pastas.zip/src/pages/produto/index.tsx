import React from 'react';
import { Text, View, TextInput, TouchableOpacity, SafeAreaView } from 'react-native';
import AntDesign from '@expo/vector-icons/AntDesign';
import Entypo from '@expo/vector-icons/Entypo';
import FontAwesome5 from '@expo/vector-icons/FontAwesome5';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';

import { style } from './styles';

export default function Produto() {
  return (
    <SafeAreaView style={style.principal}>
      <View style={style.conteudo}>

        <View style={style.cabecalho}>
          <AntDesign name="inbox" size={24} color="black" />
          <Text style={style.titulo}>Novo Produto</Text>
        </View>

        <View style={style.formulario}>

          <View style={style.grupoentrada}>
            <View style={style.caixaentrada}>
              <Entypo name="price-tag" size={24} color="black" />
              <TextInput
                style={style.entrada}
                placeholder="Nome do Produto"
                placeholderTextColor="#fafafa"
              />
            </View>
            <View style={style.fundorotulo}>
              <Text style={style.rotulo}>Nome</Text>
            </View>
          </View>

          <View style={style.grupoentrada}>
            <View style={[style.caixaentrada, style.caixasemfoco]}>
              <FontAwesome5 name="money-bill" size={24} color="black" />
              <TextInput
                style={style.entrada}
                placeholder="R$ 0,00"
                placeholderTextColor="#888"
                keyboardType="numeric"
              />
            </View>
            <View style={style.fundorotulo}>
              <Text style={[style.rotulo, style.rotulosemfoco]}>Preço</Text>
            </View>
          </View>

          <View style={style.grupoentrada}>
            <View style={style.caixaentrada}>
              <MaterialCommunityIcons name="inbox-outline" size={28} color="#666" style={style.icone} />
              <TextInput
                style={style.entrada}
                placeholder="0"
                placeholderTextColor="#888"
                keyboardType="numeric"
              />
            </View>
            <View style={style.fundorotulo}>
              <Text style={style.rotulo}>Quantidade de Entrada</Text>
            </View>
          </View>

        </View>

        <TouchableOpacity style={style.botao} activeOpacity={0.8}>
          <Text style={style.textobotao}>CADASTRAR PRODUTO</Text>
        </TouchableOpacity>

      </View>
    </SafeAreaView>
  );
}