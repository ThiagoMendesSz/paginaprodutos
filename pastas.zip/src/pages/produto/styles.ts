import { StyleSheet } from 'react-native';

export const style = StyleSheet.create({
  principal: {
    flex: 1,
    backgroundColor: '#F5F8FF',
  },
  conteudo: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 60,
  },
  cabecalho: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 40,
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#111',
    marginLeft: 12,
  },
  formulario: {
    marginBottom: 40,
  },
  grupoentrada: {
    marginBottom: 24,
    position: 'relative',
  },
  caixaentrada: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#1A5FAD',
    borderRadius: 8,
    paddingHorizontal: 16,
    height: 60,
    backgroundColor: 'transparent',
  },
  caixasemfoco: {
    borderColor: '#888',
  },
  icone: {
    marginRight: 12,
  },
  entrada: {
    flex: 1,
    fontSize: 18,
    color: '#333',
    height: '100%',
  },
  fundorotulo: {
    position: 'absolute',
    top: -10,
    left: 20,
    backgroundColor: '#F5F8FF',
    paddingHorizontal: 6,
  },
  rotulo: {
    color: '#1A5FAD',
    fontSize: 14,
    fontWeight: '500',
  },
  rotulosemfoco: {
    color: '#666',
  },
  botao: {
    backgroundColor: '#1A5FAD',
    borderRadius: 6,
    height: 56,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  textobotao: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 0.5,
  },
});