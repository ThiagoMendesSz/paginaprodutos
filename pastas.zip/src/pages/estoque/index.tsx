import React from "react";
import { View, FlatList } from "react-native";

import { style } from "./styles";
import { CardEstoque } from "../../components/cardEstoque";

console.log("CardEstoque:", CardEstoque);
const produtos = [
    { id: '1', nome: 'Teclado', quantidade: 54, status: 'Estoque' },
    { id: '2', nome: 'Mouse', quantidade: 3, status: 'Estoque Baixo' },
    { id: '3', nome: 'Headset', quantidade: 21, status: 'Estoque' },
] as const;

export default function Estoque(){
    return(
        <View style={style.container}>

            <FlatList
                data={produtos}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                    <CardEstoque
                        nome={item.nome}
                        quantidade={item.quantidade}
                        status={item.status}
                    />
                )}
            />

        </View>
    )
}