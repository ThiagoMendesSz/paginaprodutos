import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { MaterialCommunityIcons, Ionicons, Entypo } from "@expo/vector-icons";
import Produto from "../pages/produto";
import Saida from "../pages/saida";
import Estoque from "../pages/estoque";
import { themas } from "../global/themes";

const Tab = createBottomTabNavigator();

export default function BottomRoutes(){
    return(
        <Tab.Navigator
            initialRouteName="Produto"
            screenOptions={{
                tabBarActiveTintColor: themas.Colors.primary,
                tabBarInactiveTintColor: themas.Colors.blackTransparent
            }}
        >

            <Tab.Screen
                name="Produto"
                component={Produto}
                options={{
                    title: "Novo Produto",
                    tabBarLabel: "Novo",
                    tabBarIcon: ({ color, size }) => (
                        <MaterialCommunityIcons name="package-variant-plus" color={color} size={size} />
                    )
                }}>
            </Tab.Screen>

            <Tab.Screen
                name="Saida"
                component={Saida}
                options={{
                    title: "Saída de Produto",
                    tabBarLabel: "Saída",
                    tabBarIcon: ({ color, size }) => (
                        <Ionicons name="exit-outline" color={color} size={size} />
                    )
                }}>
            </Tab.Screen>

            <Tab.Screen
                name="Estoque"
                component={Estoque}
                options={{
                    title: "Controle de Estoque",
                    tabBarLabel: "Estoque",
                    tabBarIcon: ({ color, size }) => (
                        <Entypo name="box" color={color} size={size} />
                    )
                }}>
            </Tab.Screen>


        </Tab.Navigator>
    )
}