import React from "react";
import { Text, View } from "react-native";
import { Entypo } from "@expo/vector-icons";
import { style } from "./styles";
import { themas } from "../../global/themes";

type Props = {
    nome: string,
    quantidade: number,
    status: "Em Estoque" | "Estoque Baixo"
}

export function CardEstoque({ nome, quantidade, status }: Props) {
    const baixo = status === "Estoque Baixo";
    const corStatus = baixo ? "#ff9e9e" : "#365538";

    return (
        <View style={style.card}>

            <Entypo
                name="box"
                size={32}
                color={themas.Colors.primary}
            />

            <View style={style.info}>
                <Text style={style.nome}>{nome}</Text>
                <Text style={style.quantidade}>Quantidade: {quantidade}</Text>
            </View>

            <View style={[style.badge, { backgroundColor: corStatus }]}>
                <Text style={style.textBadge}>{status}</Text>
            </View>

        </View>
    )
}