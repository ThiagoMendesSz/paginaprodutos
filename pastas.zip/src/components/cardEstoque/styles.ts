import { StyleSheet } from "react-native";
import { themas } from "../../global/themes";

export const style = StyleSheet.create({
    card:{
        flexDirection:'row',
        alignItems:'center',
        backgroundColor:themas.Colors.bgScreen,
        borderRadius:12,
        padding:14,
        marginBottom:12
    },
    info:{
        flex:1,
        marginLeft:12
    },
    nome:{
        fontSize:16,
        fontWeight:'bold'
    },
    quantidade:{
        marginTop:2,
        color:themas.Colors.gray
    },
    badge:{
        paddingHorizontal:10,
        paddingVertical:5,
        borderRadius:20
    },
    textBadge:{
        color:'#FFF',
        fontSize:12,
        fontWeight:'bold'
    }
})