export const themas ={
    Colors :{
        primary:'#1A5FAD',
        secondary:'#ffffff',
        lightGray:'#fdfdfd',
        gray:'gray',
        bgScreen:'#f1f7fa',
        red:'#FF494C',
        blueLigth:'#134e70ff',
        blackTransparent:'#00000040'
    }
}